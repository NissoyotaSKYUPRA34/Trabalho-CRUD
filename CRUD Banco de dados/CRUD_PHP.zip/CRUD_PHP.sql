CREATE DATABASE biblioteca; #banco de dados
USE biblioteca; #tem que usar isso aqui pra iniciar o banco de dados

###############################################################


CREATE TABLE livros_tb ( #criando a tabela 
	ID INT PRIMARY KEY AUTO_INCREMENT,
	Nome VARCHAR(60) NOT NULL,
	Gênero VARCHAR(60) NOT NULL
    );	
    
    
###############################################################

SELECT * FROM livros_tb; #lê os arquivos da tabela

DROP TABLE livros_tb; #deleta a tabela