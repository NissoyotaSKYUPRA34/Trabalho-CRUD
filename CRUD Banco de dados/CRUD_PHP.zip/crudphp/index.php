<?php
require 'config.php';

$lista = [];
$sql = $pdo->query("SELECT * FROM livros_tb");
if ($sql->rowCount() > 0) {
    $lista = $sql->fetchAll(PDO::FETCH_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<body>

    <div class="container">
        <h1>Listagem dos Livros</h1> <br>
        <a type="button" class="btn btn-primary" href="cadastro.php">Cadastrar Livro</a><br><br>
        <table class="table table-striped">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Gênero</th>
                <th>Ações</th>
            </tr>
            <?php foreach ($lista as $livros) : ?>
                <tr>
                    <td><?= $livros['ID']; ?></td>
                    <td><?= $livros['Nome']; ?></td>
                    <td><?= $livros['Gênero']; ?></td>
                    <td>

                        <a type="button" class="btn btn-secondary" href="editar.php?ID=<?= $livros['ID']; ?>">[ Editar ]</a>
                        <a type="button" class="btn btn-danger" href="excluir.php?ID=<?= $livros['ID']; ?>">[ Excluir ]</a>

                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>



    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>

</html>
<!-- <div>
    <h1>Listagem dos Livros</h1>
</div>


<div>
    <table class="table table-striped">
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Gênero</th>
            <th>Ações</th>
        </tr>
    <?php foreach ($lista as $livros) : ?>
        <tr>
            <td><?= $livros['ID']; ?></td>
            <td><?= $livros['Nome']; ?></td> 
            <td><?= $livros['Gênero']; ?></td>
            <td>

            <a href= "editar.php?ID=<?= $livros['ID']; ?>">[ Editar ]</a> 
            <a href= "excluir.php?ID=<?= $livros['ID']; ?>">[ Excluir ]</a>

            </td>

        </tr>
    <?php endforeach; ?>
    </table>
</div>


<a href="cadastro.php">Cadastrar Livro</a>

<link rel="stylesheet" href="style.css">
<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'> -->