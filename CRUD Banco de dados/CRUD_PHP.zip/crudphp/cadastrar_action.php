<?php
require 'config.php';

$nome = filter_input(INPUT_POST, 'nome');
$genero = filter_input(INPUT_POST, 'genero');


if ($nome && $genero) {

    $sql = $pdo->prepare('INSERT INTO livros_tb(Nome, Gênero) VALUES (:nome, :genero)');
    $sql->bindValue(':nome', $nome);
    $sql->bindValue(':genero', $genero);
    
    $sql->execute();
    
    header ("Location: index.php");
    exit;

}else{
    header ("Location: cadastro.php");
    exit;
}
