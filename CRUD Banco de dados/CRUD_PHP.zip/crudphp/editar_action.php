<?php
require 'config.php';

$ID = filter_input(INPUT_POST, 'ID');
$nome = filter_input(INPUT_POST, 'nome');
$genero = filter_input(INPUT_POST, 'genero');


if ($ID && $nome && $genero) {
    $sql = $pdo->prepare("UPDATE livros_tb SET Nome = :nome, Gênero = :genero WHERE ID = :ID");
    $sql->bindValue(':nome', $nome);
    $sql->bindValue(':genero', $genero);
    $sql->bindValue(':ID', $ID);

    $sql->execute();
 
    header("Location: index.php");
    exit;
}else{
    header("Location: editar.php");
    exit;
}