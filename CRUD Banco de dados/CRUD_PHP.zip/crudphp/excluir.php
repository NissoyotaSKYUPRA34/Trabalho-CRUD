<?php
require 'config.php';

$ID = filter_input(INPUT_GET, 'ID');


if ($ID){
    $sql = $pdo->prepare("DELETE FROM livros_tb WHERE ID = :ID");
    $sql->bindValue(':ID', $ID);
    $sql->execute();
}

header("Location: index.php");